#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import re
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path
from urllib.parse import parse_qs, urljoin, urlparse
from zoneinfo import ZoneInfo

import requests
from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
CONFIG_DIR = ROOT / "config"
SOURCE_CONFIG = CONFIG_DIR / "sources.json"
COMP_CONFIG = CONFIG_DIR / "competitions.json"
FIXTURES_CSV = DATA / "fixtures.csv"
STATE = DATA / "engine-state.json"
MATCHES = DATA / "matches.json"
COMPETITIONS = DATA / "competitions.json"
UPCOMING = DATA / "upcoming.json"
TZ = ZoneInfo("Europe/Oslo")


def read_json(path: Path, default):
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, data) -> bool:
    text = json.dumps(data, ensure_ascii=False, indent=2) + "\n"
    old = path.read_text(encoding="utf-8") if path.exists() else None
    if old == text:
        return False
    path.write_text(text, encoding="utf-8")
    return True


def load_fixtures(path: Path):
    with path.open("r", encoding="utf-8-sig", newline="") as fh:
        return list(csv.DictReader(fh))


def clean(value) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()


def compact(value) -> str:
    return re.sub(r"\s+", "", clean(value).casefold())


def parse_score(value: str):
    m = re.fullmatch(r"\s*(\d+)\s*[-–]\s*(\d+)\s*", clean(value))
    return (int(m.group(1)), int(m.group(2))) if m else None


def parse_date(value: str):
    value = clean(value)
    for fmt in ("%d.%m.%Y", "%d.%m.%y", "%Y-%m-%d"):
        try:
            return datetime.strptime(value, fmt).date()
        except ValueError:
            pass
    return None


def parse_time(value: str):
    value = clean(value)
    for fmt in ("%H:%M", "%H.%M"):
        try:
            return datetime.strptime(value, fmt).time()
        except ValueError:
            pass
    return None


def parse_dt(value: str | None):
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(value)
        return dt.replace(tzinfo=TZ) if dt.tzinfo is None else dt.astimezone(TZ)
    except ValueError:
        return None


def fiks_id_from_href(href: str | None):
    if not href:
        return None
    try:
        values = parse_qs(urlparse(href).query).get("fiksId")
        return values[0] if values and str(values[0]).isdigit() else None
    except Exception:
        return None


class Fetcher:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.session = requests.Session()
        self.session.headers.clear()
        self.session.headers.update(cfg.get("headers") or {})
        self.timeout = int(cfg.get("timeoutSeconds", 20))
        self.delay = float(cfg.get("minimumDelaySeconds", 1.5))
        self.last_request = 0.0
        self.count = 0

    def get(self, path_or_url: str) -> str:
        elapsed = time.monotonic() - self.last_request
        if elapsed < self.delay:
            time.sleep(self.delay - elapsed)
        url = path_or_url if path_or_url.startswith("http") else urljoin(self.cfg["baseUrl"], path_or_url)
        response = self.session.get(url, timeout=self.timeout, allow_redirects=True)
        self.last_request = time.monotonic()
        self.count += 1
        response.raise_for_status()
        return response.text


def resolve_tournament_id(comp: dict, state: dict, fetcher: Fetcher):
    if comp.get("tournamentId"):
        return str(comp["tournamentId"])
    saved = state.get("resolvedCompetitions", {}).get(comp["key"])
    if saved:
        return str(saved)
    discovery = comp.get("discoveryMatchFiksId")
    if not discovery:
        return None
    html = fetcher.get(f"/fotballdata/kamp/?fiksId={discovery}")
    for pattern in (
        r"/fotballdata/turnering/hjem/\?fiksId=(\d+)",
        r"/fotballdata/turnering/[^\"']*\?fiksId=(\d+)",
    ):
        m = re.search(pattern, html, re.I)
        if m:
            value = m.group(1)
            state.setdefault("resolvedCompetitions", {})[comp["key"]] = value
            return value
    return None


def header_map(row):
    return [compact(c.get_text(" ", strip=True)) for c in row.find_all(["th", "td"])]


def header_index(headers, *needles):
    for i, header in enumerate(headers):
        if any(header == n or header.startswith(n) or n in header for n in needles):
            return i
    return None


def extract_match_rows(soup: BeautifulSoup):
    found = {}

    # Prefer the structured all-matches table when present.
    for table in soup.find_all("table"):
        trs = table.find_all("tr")
        if not trs:
            continue
        headers = header_map(trs[0])
        i_no = header_index(headers, "kampnr", "kampnummer")
        i_home = header_index(headers, "hjemmelag", "heimelag")
        i_away = header_index(headers, "bortelag")
        if i_no is None or i_home is None or i_away is None:
            continue
        i_result = header_index(headers, "resultat")
        i_date = header_index(headers, "dato")
        i_time = header_index(headers, "tid")
        i_venue = header_index(headers, "bane", "stadion")
        needed = max(x for x in (i_no, i_home, i_away, i_result, i_date, i_time, i_venue) if x is not None)
        for tr in trs[1:]:
            cells = [clean(c.get_text(" ", strip=True)) for c in tr.find_all(["th", "td"])]
            if len(cells) <= needed:
                continue
            match_number = clean(cells[i_no])
            if not re.fullmatch(r"\d{8,14}", match_number):
                # Sometimes the number is wrapped in a link whose text rendering differs.
                match_number = next((c for c in cells if re.fullmatch(r"\d{8,14}", c)), "")
            if not match_number:
                continue
            score = parse_score(cells[i_result]) if i_result is not None else None
            status = None
            if i_result is not None and not score:
                token = clean(cells[i_result]).casefold()
                if token not in {"", "-"}:
                    status = token.replace(" ", "_")
            link = tr.find("a", href=re.compile(r"/fotballdata/kamp/", re.I))
            fiks_id = fiks_id_from_href(link.get("href") if link else None)
            if not fiks_id:
                m = re.search(r"/fotballdata/kamp/\?fiksId=(\d+)", str(tr), re.I)
                fiks_id = m.group(1) if m else None
            d = parse_date(cells[i_date]) if i_date is not None else None
            t = parse_time(cells[i_time]) if i_time is not None else None
            found[match_number] = {
                "score": score,
                "status": status,
                "fiksId": fiks_id,
                "date": d.isoformat() if d else None,
                "time": t.strftime("%H:%M") if t else None,
                "home": clean(cells[i_home]),
                "away": clean(cells[i_away]),
                "venue": clean(cells[i_venue]) if i_venue is not None else None,
            }

    # Fallback for responsive/alternate markup.
    if found:
        return found
    for row in soup.find_all("tr"):
        cells = [clean(cell.get_text(" ", strip=True)) for cell in row.find_all(["th", "td"])]
        match_number = next((c for c in cells if re.fullmatch(r"\d{8,14}", c)), None)
        if not match_number:
            continue
        score = next((parse_score(c) for c in cells if parse_score(c)), None)
        link = row.find("a", href=re.compile(r"/fotballdata/kamp/", re.I))
        found[match_number] = {
            "score": score,
            "status": None,
            "fiksId": fiks_id_from_href(link.get("href") if link else None),
            "date": next((d.isoformat() for d in (parse_date(c) for c in cells) if d), None),
            "time": next((t.strftime("%H:%M") for t in (parse_time(c) for c in cells) if t), None),
            "home": None,
            "away": None,
            "venue": None,
        }
    return found


def integer(value):
    m = re.search(r"-?\d+", clean(value).replace("−", "-"))
    return int(m.group()) if m else None


def find_standings_table(soup: BeautifulSoup):
    candidates = []
    for table in soup.find_all("table"):
        rows = table.find_all("tr")
        if not rows:
            continue
        headers = header_map(rows[0])
        has_team = any(h == "lag" or h.endswith("lag") for h in headers)
        has_wdl = all(any(h == token or h.startswith(token) for h in headers) for token in ("v", "u", "t"))
        has_points = any(h in {"p", "poeng"} or "poeng" in h for h in headers)
        if has_team and has_wdl and has_points:
            candidates.append((len(headers), table, headers))
    if not candidates:
        return None, None
    candidates.sort(key=lambda item: item[0])
    _, table, headers = candidates[0]
    return table, headers


def extract_standings(soup: BeautifulSoup):
    table, headers = find_standings_table(soup)
    if table is None:
        return []
    i_team = header_index(headers, "lag")
    i_played = header_index(headers, "s", "kamper", "k")
    i_wins = next((i for i, h in enumerate(headers) if h in {"v", "vunnet"}), None)
    i_draws = next((i for i, h in enumerate(headers) if h in {"u", "uavgjort"}), None)
    i_losses = next((i for i, h in enumerate(headers) if h in {"t", "tap"}), None)
    i_goals = header_index(headers, "mf", "mål")
    i_points = next((i for i, h in enumerate(headers) if h in {"p", "poeng"} or "poeng" in h), None)
    if None in (i_team, i_played, i_wins, i_draws, i_losses, i_goals, i_points):
        return []
    rows = []
    for tr in table.find_all("tr")[1:]:
        cells = [clean(c.get_text(" ", strip=True)) for c in tr.find_all(["th", "td"])]
        if len(cells) <= max(i_team, i_played, i_wins, i_draws, i_losses, i_goals, i_points):
            continue
        team = clean(cells[i_team]).lstrip("* ")
        if not team:
            continue
        played, wins, draws, losses, points = [integer(cells[i]) for i in (i_played, i_wins, i_draws, i_losses, i_points)]
        gm = re.search(r"(\d+)\s*[-–]\s*(\d+)", cells[i_goals])
        if None in (played, wins, draws, losses, points) or not gm:
            continue
        gf, ga = int(gm.group(1)), int(gm.group(2))
        rows.append({
            "position": integer(cells[0]) or len(rows) + 1,
            "team": team,
            "played": played,
            "wins": wins,
            "draws": draws,
            "losses": losses,
            "gf": gf,
            "ga": ga,
            "gd": gf - ga,
            "points": points,
        })
    return rows


def parse_tournament(html: str):
    soup = BeautifulSoup(html, "html.parser")
    return extract_match_rows(soup), extract_standings(soup)


def parse_detail(html: str):
    soup = BeautifulSoup(html, "html.parser")
    text = clean(soup.get_text(" ", strip=True))
    result = {"events": []}

    officials = {}
    role_aliases = {
        "dommer": "referee",
        "hoveddommer": "referee",
        "hd": "referee",
        "assistentdommer1": "assistant1",
        "ad1": "assistant1",
        "assistentdommer2": "assistant2",
        "ad2": "assistant2",
        "fjerdedommer": "fourthOfficial",
    }
    for tr in soup.find_all("tr"):
        cells = [clean(c.get_text(" ", strip=True)) for c in tr.find_all(["th", "td"])]
        if len(cells) < 2:
            continue
        role = compact(cells[0])
        if role in role_aliases and cells[1]:
            officials[role_aliases[role]] = cells[1]
    if officials:
        result["officials"] = officials
        if officials.get("referee"):
            result["referee"] = officials["referee"]

    for tr in soup.find_all("tr"):
        cells = [clean(c.get_text(" ", strip=True)) for c in tr.find_all(["th", "td"])]
        if len(cells) < 2:
            continue
        label = compact(cells[0])
        value = cells[1]
        if "tilskodar" in label or "tilskuer" in label:
            n = integer(value)
            if n is not None:
                result["attendance"] = n
        if label in {"pause", "pauseresultat", "ht"} and parse_score(value):
            result["halfTime"] = clean(value)

    # Only ingest event rows that are explicit and unambiguous.
    for table in soup.find_all("table"):
        trs = table.find_all("tr")
        if not trs:
            continue
        heads = header_map(trs[0])
        minute_i = header_index(heads, "minutt", "tid")
        player_i = header_index(heads, "spiller", "namn", "navn")
        event_i = header_index(heads, "hendelse", "type")
        if minute_i is None or event_i is None:
            continue
        for tr in trs[1:]:
            cells = [clean(c.get_text(" ", strip=True)) for c in tr.find_all(["th", "td"])]
            required = max(minute_i, event_i, player_i or 0)
            if len(cells) <= required:
                continue
            minute = integer(cells[minute_i])
            label = cells[event_i].casefold()
            player = cells[player_i] if player_i is not None and player_i < len(cells) else None
            event_type = None
            if "mål" in label or "goal" in label:
                event_type = "goal"
            elif "gult" in label or "yellow" in label:
                event_type = "yellow_card"
            elif "rødt" in label or "raudt" in label or "red" in label:
                event_type = "red_card"
            elif "bytte" in label or "sub" in label:
                event_type = "substitution"
            if event_type and player:
                result["events"].append({"minute": minute, "type": event_type, "player": player})

    result["hasRegisteredEvents"] = "Ingen kamphendelser registrert" not in text
    result["hasPublishedSquad"] = "Kamptropp ikke publisert eller registrert" not in text
    return result


def kickoff_dt(fixture: dict, match_state: dict):
    date_value = match_state.get("date") or fixture["date"]
    time_value = match_state.get("time") or fixture["time"]
    d, t = parse_date(date_value), parse_time(time_value)
    if not d or not t:
        return None
    return datetime.combine(d, t, TZ)


def effective_status(fixture: dict, match_state: dict):
    if match_state.get("status"):
        return match_state["status"]
    if parse_score(fixture.get("seedResult", "")):
        return "completed"
    seed = clean(fixture.get("seedResult", "")).casefold()
    return seed.replace(" ", "_") if seed else "scheduled"


def effective_score(fixture: dict, match_state: dict):
    if match_state.get("homeScore") is not None and match_state.get("awayScore") is not None:
        return int(match_state["homeScore"]), int(match_state["awayScore"])
    return parse_score(fixture.get("seedResult", ""))


def first_check_at(fixture: dict, match_state: dict, policy: dict):
    kickoff = kickoff_dt(fixture, match_state)
    if not kickoff:
        return None
    offsets = policy.get("firstCheckMinutes") or {}
    return kickoff + timedelta(minutes=int(offsets.get(fixture.get("age"), 110)))


def retry_at(now: datetime, attempts: int, policy: dict):
    retries = policy.get("retryMinutes") or [10, 20, 40, 75, 120]
    if attempts <= len(retries):
        return now + timedelta(minutes=int(retries[attempts - 1]))
    target = now.replace(hour=int(policy.get("nextMorningHour", 7)), minute=0, second=0, microsecond=0)
    if target <= now:
        target += timedelta(days=1)
    return target


def should_daily_refresh(now: datetime, cfg: dict, state: dict):
    if now.hour != int(cfg.get("dailyRefreshHour", 6)):
        return False
    return state.get("lastDailyRefresh") != now.date().isoformat()


def source_url(base_url: str, tournament_id: str | None, fiks_id: str | None):
    if fiks_id:
        return f"{base_url}/fotballdata/kamp/?fiksId={fiks_id}"
    if tournament_id:
        return f"{base_url}/fotballdata/turnering/hjem/?fiksId={tournament_id}"
    return None


def build_outputs(fixtures: list[dict], state: dict, comp_cfg: dict, existing_matches: dict, competition_output: dict, base_url: str):
    now = datetime.now(TZ)
    comp_by_key = {c["key"]: c for c in comp_cfg.get("competitions", [])}
    old_by_number = {m.get("matchNumber"): m for m in existing_matches.get("matches", []) if m.get("matchNumber")}
    completed, future = [], []

    for fixture in fixtures:
        number = fixture["matchNumber"]
        ms = state.get("matches", {}).get(number, {})
        status = effective_status(fixture, ms)
        score = effective_score(fixture, ms)
        comp = comp_by_key.get(fixture["competitionKey"], {})
        tournament_id = comp.get("tournamentId") or state.get("resolvedCompetitions", {}).get(fixture["competitionKey"])
        fiks_id = ms.get("fiksId")
        local_team = clean(fixture.get("localTeam")) or None
        date_value = ms.get("date") or fixture["date"]
        time_value = ms.get("time") or fixture["time"]
        venue = ms.get("venue") or fixture.get("venue") or None
        home = ms.get("home") or fixture["home"]
        away = ms.get("away") or fixture["away"]

        if local_team and status == "completed" and score:
            old = old_by_number.get(number, {})
            detail = ms.get("detail") or {}
            identity = fiks_id or number
            item = {
                "id": f"match-{identity}",
                "fiksId": fiks_id,
                "matchNumber": number,
                "sourceUrl": source_url(base_url, tournament_id, fiks_id),
                "date": date_value,
                "time": time_value,
                "age": fixture["age"],
                "competition": fixture["competition"],
                "competitionId": fixture["competitionKey"],
                "venue": venue,
                "home": home,
                "away": away,
                "homeScore": score[0],
                "awayScore": score[1],
                "halfTime": detail.get("halfTime", old.get("halfTime")),
                "localTeam": local_team,
                "events": detail.get("events") or old.get("events") or [],
                "summary": old.get("summary"),
                "nextMatch": None,
                "source": "fotball.no",
            }
            for field in ("officials", "referee", "attendance", "lineups"):
                value = detail.get(field, old.get(field))
                if value is not None:
                    item[field] = value
            completed.append(item)

        if local_team and status == "scheduled":
            kickoff = kickoff_dt(fixture, ms)
            if kickoff and kickoff >= now - timedelta(hours=2):
                future.append({
                    "date": date_value,
                    "time": time_value,
                    "age": fixture["age"],
                    "competition": fixture["competition"],
                    "venue": venue,
                    "home": home,
                    "away": away,
                    "matchNumber": number,
                    "sourceUrl": source_url(base_url, tournament_id, fiks_id),
                })

    completed.sort(key=lambda m: (m["date"], m.get("time") or ""), reverse=True)
    future.sort(key=lambda m: (m["date"], m.get("time") or ""))
    return (
        {
            "generatedAt": now.isoformat(timespec="seconds"),
            "photoSubmitUrl": existing_matches.get("photoSubmitUrl", "#"),
            "matches": completed,
        },
        {"generatedAt": now.isoformat(timespec="seconds"), "matches": future},
        competition_output,
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    source_cfg = read_json(SOURCE_CONFIG, {})
    comp_cfg = read_json(COMP_CONFIG, {"policy": {}, "competitions": []})
    fixtures = load_fixtures(FIXTURES_CSV)
    state = read_json(STATE, {"version": 1, "lastDailyRefresh": None, "matches": {}, "resolvedCompetitions": {}})
    state.setdefault("matches", {})
    state.setdefault("resolvedCompetitions", {})
    existing_matches = read_json(MATCHES, {"matches": []})
    competition_output = read_json(COMPETITIONS, {"competitions": {}})
    competition_output.setdefault("competitions", {})

    now = datetime.now(TZ)
    policy = comp_cfg.get("policy") or {}
    daily = should_daily_refresh(now, source_cfg, state)
    comp_by_key = {c["key"]: c for c in comp_cfg.get("competitions", [])}

    due_by_comp = {}
    for fixture in fixtures:
        ms = state["matches"].setdefault(fixture["matchNumber"], {})
        if effective_status(fixture, ms) != "scheduled":
            continue
        due = parse_dt(ms.get("nextCheckAt")) or first_check_at(fixture, ms, policy)
        if due and now >= due:
            due_by_comp.setdefault(fixture["competitionKey"], []).append(fixture)

    detail_due = []
    for fixture in fixtures:
        ms = state["matches"].setdefault(fixture["matchNumber"], {})
        if not fixture.get("localTeam") or effective_status(fixture, ms) != "completed" or not ms.get("fiksId"):
            continue
        due = parse_dt(ms.get("detailNextCheckAt"))
        if due and now >= due and int(ms.get("detailFetches", 0)) < int(source_cfg.get("maxDetailFetches", 2)):
            detail_due.append(fixture)

    if not args.force and not daily and not due_by_comp and not detail_due:
        print("No network work due.")
        return 0

    fetcher = Fetcher(source_cfg)
    keys = set(comp_by_key) if (args.force or daily) else set(due_by_comp)
    result_updates = 0
    detail_updates = 0
    newly_completed = set()
    detail_budget = int(source_cfg.get("detailBudgetPerRun", 8))

    for key in sorted(keys):
        comp = comp_by_key.get(key)
        if not comp:
            continue
        tournament_id = resolve_tournament_id(comp, state, fetcher)
        if not tournament_id:
            continue
        html = fetcher.get(f"/fotballdata/turnering/hjem/?fiksId={tournament_id}")
        remote_rows, standings = parse_tournament(html)

        if standings:
            competition_output["competitions"][key] = {
                "name": comp["name"],
                "tournamentId": tournament_id,
                "updatedAt": now.isoformat(timespec="seconds"),
                "standings": standings,
            }

        for fixture in (f for f in fixtures if f["competitionKey"] == key):
            remote = remote_rows.get(fixture["matchNumber"])
            if not remote:
                continue
            ms = state["matches"].setdefault(fixture["matchNumber"], {})
            if remote.get("fiksId"):
                ms["fiksId"] = remote["fiksId"]
            for field in ("date", "time", "home", "away", "venue"):
                if remote.get(field):
                    ms[field] = remote[field]
            if remote.get("score"):
                hs, as_ = remote["score"]
                old_score = effective_score(fixture, ms)
                was_completed = effective_status(fixture, ms) == "completed"
                if not was_completed or old_score != (hs, as_):
                    result_updates += 1
                if not was_completed:
                    newly_completed.add(fixture["matchNumber"])
                ms["homeScore"], ms["awayScore"] = hs, as_
                ms["status"] = "completed"
                ms["resultAt"] = now.isoformat(timespec="seconds")
                ms.pop("nextCheckAt", None)
            elif remote.get("status"):
                ms["status"] = remote["status"]

        for fixture in due_by_comp.get(key, []):
            ms = state["matches"].setdefault(fixture["matchNumber"], {})
            if effective_status(fixture, ms) == "completed":
                continue
            attempts = int(ms.get("attempts", 0)) + 1
            ms["attempts"] = attempts
            ms["lastAttemptAt"] = now.isoformat(timespec="seconds")
            ms["nextCheckAt"] = retry_at(now, attempts, policy).isoformat(timespec="seconds")

        # Detail fetches are limited to newly completed or very recent local games.
        # This avoids a large historical backfill on the first forced refresh.
        recent_cutoff = now - timedelta(days=int(source_cfg.get("initialDetailLookbackDays", 3)))
        for fixture in (f for f in fixtures if f["competitionKey"] == key and f.get("localTeam")):
            if detail_updates >= detail_budget:
                break
            ms = state["matches"].setdefault(fixture["matchNumber"], {})
            if effective_status(fixture, ms) != "completed" or not ms.get("fiksId") or int(ms.get("detailFetches", 0)) > 0:
                continue
            kickoff = kickoff_dt(fixture, ms)
            is_recent = bool(kickoff and kickoff >= recent_cutoff)
            if fixture["matchNumber"] not in newly_completed and not is_recent:
                continue
            detail = parse_detail(fetcher.get(f"/fotballdata/kamp/?fiksId={ms['fiksId']}"))
            ms["detail"] = {k: v for k, v in detail.items() if k not in {"hasRegisteredEvents", "hasPublishedSquad"}}
            ms["detailFetches"] = 1
            ms["detailFetchedAt"] = now.isoformat(timespec="seconds")
            if not detail.get("hasRegisteredEvents") or not detail.get("hasPublishedSquad"):
                ms["detailNextCheckAt"] = (now + timedelta(minutes=int(source_cfg.get("detailRetryMinutes", 60)))).isoformat(timespec="seconds")
            detail_updates += 1

    for fixture in detail_due:
        if detail_updates >= detail_budget:
            break
        ms = state["matches"].setdefault(fixture["matchNumber"], {})
        detail = parse_detail(fetcher.get(f"/fotballdata/kamp/?fiksId={ms['fiksId']}"))
        ms["detail"] = {k: v for k, v in detail.items() if k not in {"hasRegisteredEvents", "hasPublishedSquad"}}
        ms["detailFetches"] = int(ms.get("detailFetches", 0)) + 1
        ms["detailFetchedAt"] = now.isoformat(timespec="seconds")
        ms.pop("detailNextCheckAt", None)
        detail_updates += 1

    if daily:
        state["lastDailyRefresh"] = now.date().isoformat()

    matches_out, upcoming_out, competition_output = build_outputs(
        fixtures, state, comp_cfg, existing_matches, competition_output, source_cfg["baseUrl"].rstrip("/")
    )

    changed = False
    changed |= write_json(STATE, state)
    changed |= write_json(MATCHES, matches_out)
    changed |= write_json(UPCOMING, upcoming_out)
    changed |= write_json(COMPETITIONS, competition_output)

    print(f"Requests: {fetcher.count}; results: {result_updates}; details: {detail_updates}; changed: {int(changed)}.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"Sync failed: {type(exc).__name__}", file=sys.stderr)
        raise
